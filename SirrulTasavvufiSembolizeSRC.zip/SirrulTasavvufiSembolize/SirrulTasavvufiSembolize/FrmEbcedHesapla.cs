﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmEbcedHesapla : Form
    {
        public FrmEbcedHesapla()
        {
            InitializeComponent();
        }

        private void BtnEbcedHesapla_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtYaziArap.Text))
            {
                long sonuc1 = EbcedHelper.ComputeEbcedValue(txtYaziArap.Text);
                FrmEbcedSonuc sonuc2 = new FrmEbcedSonuc();
                sonuc2.sonuc1 = sonuc1.ToString();
                sonuc2.Show();
            }
        }

        private void FrmEbcedHesapla_Load(object sender, EventArgs e)
        {

        }
    }
}
