﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmLatinToArabic : Form
    {
        public FrmLatinToArabic()
        {
            InitializeComponent();
        }

        private void BtnDonustur_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDeger.Text))
            {
                txtSonuc.Text = LatinToArabicConverter.Convert(txtDeger.Text);
            }
        }
    }
}
