﻿using System;
using System.Collections.Generic;
using System.Numeric;
using System.Linq;
using System.Text;

namespace SirrulTasavvufiSembolize
{
    class EbcedTool
    {
        
    }
    public class EbcedReverse
    {
        // **Ebced Tablosu** (Arapça harfler ve sayısal değerleri)
        private static readonly Dictionary<Int64, string> EbcedTable = new Dictionary<Int64, string>
    {
        {1, "ا"}, {2, "ب"}, {3, "ج"}, {4, "د"}, {5, "ه"},
        {6, "و"}, {7, "ز"}, {8, "ح"}, {9, "ط"}, {10, "ي"},
        {20, "ك"}, {30, "ل"}, {40, "م"}, {50, "ن"}, {60, "س"},
        {70, "ع"}, {80, "ف"}, {90, "ص"}, {100, "ق"}, {200, "ر"},
        {300, "ش"}, {400, "ت"}, {500, "ث"}, {600, "خ"}, {700, "ذ"},
        {800, "ض"}, {900, "ظ"}, {1000, "غ"}
    };

        // **Özel İsimler** (Direkt karşılık gelen kelimeler)
        private static readonly Dictionary<Int64, string> SpecialNames = new Dictionary<Int64, string>
    {
        {94, "محمد"},  // Muhammed
        {66, "الله"},  // Allah
        {285, "ابراهيم"}, // İbrahim
        {195, "حسن"},  // Hasan
        {156, "علي"},  // Ali
        {92, "فاطمة"},  // Fatıma
        {703, "يوسف"},  // Yusuf
        {955, "اسماعيل"} // İsmail
    };

        public static string ConvertNumberToArabic(Int64 number)
        {
            // **Özel isimleri kontrol et**
            if (SpecialNames.ContainsKey(number))
                return SpecialNames[number];

            StringBuilder result = new StringBuilder();
            List<Int64> keys = EbcedTable.Keys.OrderByDescending(x => x).ToList(); // **Büyükten küçüğe sırala**

            foreach (Int64 key in keys)
            {
                while (number >= key)
                {
                    number -= key;
                    result.Append(EbcedTable[key]); // **Harf ekle**
                }
            }

            return result.ToString();
        }
    }
    public class EbcedHelper
    {
        // **Ebced Harf Tablosu** (Arapça harfler ve değerleri)
        private static readonly Dictionary<char, int> EbcedAlphabet = new Dictionary<char, int>
    {
        {'ا', 1}, {'ب', 2}, {'ج', 3}, {'د', 4}, {'ه', 5}, {'و', 6}, {'ز', 7},
        {'ح', 8}, {'ط', 9}, {'ي', 10}, {'ك', 20}, {'ل', 30}, {'م', 40}, {'ن', 50},
        {'س', 60}, {'ع', 70}, {'ف', 80}, {'ص', 90}, {'ق', 100}, {'ر', 200}, 
        {'ش', 300}, {'ت', 400}, {'ث', 500}, {'خ', 600}, {'ذ', 700}, {'ض', 800}, 
        {'ظ', 900}, {'غ', 1000}
    };

        // **Latin → Arapça Çeviri** (Özel isimler)
        private static readonly Dictionary<string, string> LatinToArabic = new Dictionary<string, string>
    {
        {"mehmet", "محمد"},
        {"ahmet", "احمد"},
        {"ali", "علي"},
        {"hasan", "حسن"},
        {"fatima", "فاطمة"},
        {"ibrahim", "ابراهيم"}
    };

        // **Ebced Sayısından Arapça'ya Ters Dönüşüm**
        private static readonly Dictionary<Int64, string> SpecialNames = new Dictionary<Int64, string>
    {
        {94, "محمد"}, {66, "الله"}, {285, "ابراهيم"}, {195, "حسن"}, {156, "علي"},
        {92, "فاطمة"}, {703, "يوسف"}, {955, "اسماعيل"}
    };

        private static readonly Dictionary<Int64, string> EbcedReverseTable = new Dictionary<Int64, string>
    {
        {1, "ا"}, {2, "ب"}, {3, "ج"}, {4, "د"}, {5, "ه"},
        {6, "و"}, {7, "ز"}, {8, "ح"}, {9, "ط"}, {10, "ي"},
        {20, "ك"}, {30, "ل"}, {40, "م"}, {50, "ن"}, {60, "س"},
        {70, "ع"}, {80, "ف"}, {90, "ص"}, {100, "ق"}, {200, "ر"},
        {300, "ش"}, {400, "ت"}, {500, "ث"}, {600, "خ"}, {700, "ذ"},
        {800, "ض"}, {900, "ظ"}, {1000, "غ"}
    };

        // **Ebced Hesaplama**
        public static Int64 ComputeEbcedValue(string arabicText)
        {
            Int64 sum = 0;
            foreach (char letter in arabicText)
            {
                if (EbcedAlphabet.ContainsKey(letter))
                    sum += EbcedAlphabet[letter];
            }
            return sum;
        }

        // **Latin → Arapça Çevirme**
        public static string ConvertLatinToArabic(string latinText)
        {
            string lowerText = latinText.ToLower();
            return LatinToArabic.ContainsKey(lowerText) ? LatinToArabic[lowerText] : "";
        }

        // **Ebced Sayısından Arapça'ya Geri Dönüş**
        public static string ConvertNumberToArabic(Int64 number)
        {
            if (SpecialNames.ContainsKey(number))
                return SpecialNames[number];

            StringBuilder result = new StringBuilder();
            List<Int64> keys = EbcedReverseTable.Keys.OrderByDescending(x => x).ToList();

            foreach (Int64 key in keys)
            {
                while (number >= key)
                {
                    number -= key;
                    result.Append(EbcedReverseTable[key]);
                }
            }

            return result.ToString();
        }
    }

    public class LatinToArabicConverter
    {
        private static Dictionary<char, string> latinToArabicMap = new Dictionary<char, string>
    {
        {'a', "ا"}, {'b', "ب"}, {'c', "ج"}, {'ç', "ج"}, {'d', "د"}, {'e', "ه"}, {'f', "ف"}, {'g', "ج"},
        {'ğ', "غ"}, {'h', "ح"}, {'ı', "ع"}, {'i', "ا"}, {'j', "ج"}, {'k', "ك"}, {'l', "ل"}, {'m', "م"},
        {'n', "ن"}, {'o', "و"}, {'ö', "و"}, {'p', "ب"}, {'r', "ر"}, {'s', "س"}, {'ş', "س"}, {'t', "ت"},
        {'u', "و"}, {'ü', "و"}, {'v', "و"}, {'y', "ي"}, {'z', "ز"}
    };

        public static string Convert(string latinText)
        {
            var arabicText = string.Empty;

            foreach (char c in latinText.ToLower())
            {
                if (latinToArabicMap.ContainsKey(c))
                {
                    arabicText += latinToArabicMap[c];
                }
                else
                {
                    arabicText += c; // Eğer harf eşleşmiyorsa, Latin harfini olduğu gibi bırak
                }
            }

            return arabicText;
        }
    }
    class RemilConverterSmall
{
    // Remil sistemine göre Arapça harf karşılıkları
    private static readonly Dictionary<int, string> RemilTable = new Dictionary<int, string>
    {
        {0, "ا"}, {1, "ب"}, {2, "ج"}, {3, "د"}, {4, "ه"}, {5, "و"}, {6, "ز"}, {7, "ح"},
        {8, "ط"}, {9, "ي"}
    };

    public static string ConvertToRemil(Int64 number)
    {
        StringBuilder result = new StringBuilder();
        Int64 temp = number; 

        while (temp > 0)
        {
            int remilValue = (int)(temp % 10);  // Sayıyı basamaklarına ayır
            if (RemilTable.ContainsKey(remilValue))
            {
                result.Insert(0, RemilTable[remilValue]);  // Baştan ekleyerek sırayı koru
            }
            temp /= 10;
        }

        return result.ToString();
    }

}
    class AdvancedRemilConverter
    {
        // Genişletilmiş Remil tablosu
        private static readonly Dictionary<int, string> ExpandedRemilTable = new Dictionary<int, string>
    {
        {0, "ا"}, {1, "ب"}, {2, "ج"}, {3, "د"}, {4, "ه"}, {5, "و"}, {6, "ز"}, {7, "ح"},
        {8, "ط"}, {9, "ي"}, {10, "ك"}, {20, "ل"}, {30, "م"}, {40, "ن"}, {50, "س"},
        {60, "ع"}, {70, "ف"}, {80, "ص"}, {90, "ق"}, {100, "ر"}, {200, "ش"}, {300, "ت"},
        {400, "ث"}, {500, "خ"}, {600, "ذ"}, {700, "ض"}, {800, "ظ"}, {900, "غ"},
        {1000, "ء"} // Binlik değerler için
    };

        public static string ConvertToAdvancedRemil(Int64 number)
        {
            StringBuilder result = new StringBuilder();
            Int64 temp = number;

            while (temp > 0)
            {
                int digit = (int)(temp % 10); // Son basamağı al
                if (ExpandedRemilTable.ContainsKey(digit))
                {
                    result.Insert(0, ExpandedRemilTable[digit]); // Baştan ekleyerek sırayı koru
                }
                temp /= 10;
            }

            return result.ToString();
        }
    }


}
