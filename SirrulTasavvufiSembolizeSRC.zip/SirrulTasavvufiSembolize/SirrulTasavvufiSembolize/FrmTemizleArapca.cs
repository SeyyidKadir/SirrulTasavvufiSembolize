﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmTemizleArapca : Form
    {
        public FrmTemizleArapca()
        {
            InitializeComponent();
        }

        private void BtnTemizle_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtArapcaMetin.Text))
            {
                txtSonuc.Text = ArapcaTemizleyici.Temizle(txtArapcaMetin.Text);
            }
        }
    }
}
