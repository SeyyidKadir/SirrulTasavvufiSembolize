﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
namespace SirrulTasavvufiSembolize
{
    class kuran
    {
        JArray ar1;
        public enum AramaAyarlari{
         Arapca,
            Turkce
        
        };
        public int Sureuzunluklar()
        {
            if (ar1 != null)
            {
                return ar1.Count;
            }
            else
            {
                return 0;
            }
        }
        public kuran()
        {
          ar1 = JArray.Parse(Encoding.UTF8.GetString(Resource1.quran_tr));
        }
        public Sure SureAl(int id)
        {
            Sure sureal1 = new Sure();
            JToken ilgili1 = ar1[id];
            JToken ayetler = ilgili1["verses"];
            sureal1.AyetNo = (int)ilgili1["id"];
            sureal1.OrjinalAyetAd = ilgili1["name"].ToString();
            sureal1.AyetAd = ilgili1["transliteration"].ToString();
            List<string> mealayetler = new List<string>();
            List<string> gercekayetler = new List<string>();
            for (int i = 0; i < ayetler.Count(); i++)
            {
                mealayetler.Add(ayetler[i]["translation"].ToString());
                gercekayetler.Add(ayetler[i]["text"].ToString());
            }
            sureal1.Gercek = gercekayetler.ToArray();
            sureal1.Meal = mealayetler.ToArray();
            return sureal1;
        }
        public Sure[] Arama(string kelime, AramaAyarlari ayarlar)
        {
            List<Sure> sonuc = new List<Sure>();
            if (ayarlar == AramaAyarlari.Arapca)
            {
                for (int i = 0; i < ar1.Count; i++)
                {
                    JToken ayet1 = ar1[i];
                    if (ayet1["name"].Contains(kelime))
                    {
                        sonuc.Add(SureAl(i));
                    }
                    else {
                        Sure suregecici = SureAl(i);
                        for (int j = 0; j < suregecici.Gercek.Length; j++)
                        {
                            if (suregecici.Gercek[j].Contains(kelime))
                            {
                                sonuc.Add(suregecici);
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < ar1.Count; i++)
                {
                    JToken ayet1 = ar1[i];
                    if (ayet1["transliteration"].ToString().ToLower().Contains(kelime.ToLower()))
                    {
                        sonuc.Add(SureAl(i));
                    }
                    else
                    {
                        Sure suregecici = SureAl(i);
                        for (int j = 0; j < suregecici.Meal.Length; j++)
                        {
                            if (suregecici.Meal[j].ToLower().Contains(kelime.ToLower()))
                            {
                                sonuc.Add(suregecici);
                                break;
                            }
                        }
                    }
                }
            
            }
            return sonuc.ToArray();
        }

    }
    class Sure {
        private string _isim;
        private string[] _gercek;
        private string[] _meal;
        private int _AyetNo;
        private string _isimOrjinal;
        public string[] Gercek {
            get
            {
                return this._gercek;
            }
            set
            {
                this._gercek = value;
            }
        }
        public string[] Meal {
            get
            {
                return this._meal;
            }
            set
            {
                this._meal = value;
            }
        }
        public int AyetNo {
            get
            {
                return this._AyetNo;
            }
            set
            {
                this._AyetNo = value;
            }
        }
        public string AyetAd {
            get
            {
                return this._isim;
            }
            set
            {
                this._isim = value;
            }
        
        }
        public string OrjinalAyetAd
        {
            get
            {
                return this._isimOrjinal;
            }
            set
            {
                this._isimOrjinal = value;
            }

        }
    }
}
