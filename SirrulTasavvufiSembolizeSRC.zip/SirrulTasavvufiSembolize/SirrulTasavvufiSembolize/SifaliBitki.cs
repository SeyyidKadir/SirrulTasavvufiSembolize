﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SirrulTasavvufiSembolize
{
    public class BitkiDetay
    {
        public string Bitki { get; set; }
        public string Detay { get; set; }

        public BitkiDetay(string bitki, string detay)
        {
            Bitki = bitki;
            Detay = detay;
        }
    }
    public class STS_Sifa
    {
        private static readonly Dictionary<string, BitkiDetay> ebcedBitkileri = new Dictionary<string, BitkiDetay>
    {
        {"ا", new BitkiDetay("Erik", "Bağışıklık sistemini güçlendirir, sindirimi destekler, karaciğeri temizler.")},
        {"ب", new BitkiDetay("Basal (Soğan)", "Antibakteriyel, kan basıncını düzenleyici, bağışıklık güçlendirici.")},
        {"ت", new BitkiDetay("Tere", "C vitamini kaynağı, iştah açıcı, kan dolaşımını hızlandırıcı.")},
        {"ث", new BitkiDetay("Zencefil", "Mide bulantısını giderici, bağışıklık artırıcı, iltihap önleyici.")},
        {"ج", new BitkiDetay("Ceviz", "Beyin fonksiyonlarını destekleyici, Omega-3 kaynağı, hafıza güçlendirici.")},
        {"ح", new BitkiDetay("Hindiba", "Karaciğer dostu, safra üretimini artırıcı, sindirimi kolaylaştırıcı.")},
        {"خ", new BitkiDetay("Hurma", "Kan yapıcı, enerji verici, mide koruyucu.")},
        {"د", new BitkiDetay("Dut", "Kansızlığa iyi gelir, antioksidan kaynağı, bağışıklık sistemini güçlendirir.")},
        {"ذ", new BitkiDetay("Defne", "Antiseptik, ağrı kesici, cilt yenileyici.")},
        {"ر", new BitkiDetay("Rezene", "Gaz giderici, mide rahatlatıcı, anne sütünü artırıcı.")},
        {"ز", new BitkiDetay("Zeytin", "Kalp dostu, antioksidan kaynağı, sindirimi destekleyici.")},
        {"س", new BitkiDetay("Susam", "Kemik sağlığını destekleyici, E vitamini kaynağı, bağışıklık güçlendirici.")},
        {"ش", new BitkiDetay("Şeftali", "Sindirim sistemini düzenleyici, cilt sağlığını destekleyici, idrar söktürücü.")},
        {"ص", new BitkiDetay("Sarımsak", "Doğal antibiyotik, tansiyon düzenleyici, damar açıcı.")},
        {"ض", new BitkiDetay("Darı", "Glutensiz tahıl, mide dostu, enerji verici.")},
        {"ط", new BitkiDetay("Tarçın", "Kan şekerini dengeleyici, antioksidan, metabolizma hızlandırıcı.")},
        {"ظ", new BitkiDetay("Zerdeçal", "İltihap önleyici, karaciğer dostu, bağışıklık güçlendirici.")},
        {"ع", new BitkiDetay("Anason", "Sinir yatıştırıcı, mideyi rahatlatıcı, gaz giderici.")},
        {"غ", new BitkiDetay("Gül", "Rahatlatıcı, stres azaltıcı, cilt yenileyici.")},
        {"ف", new BitkiDetay("Fesleğen", "Bağışıklık destekleyici, sindirim düzenleyici, stres azaltıcı.")},
        {"ق", new BitkiDetay("Kekik", "Solunum yollarını açıcı, bağışıklık güçlendirici, antiseptik.")},
        {"ك", new BitkiDetay("Kimyon", "Şişkinliği azaltıcı, sindirimi destekleyici, mide koruyucu.")},
        {"ل", new BitkiDetay("Limon", "C vitamini deposu, bağışıklık artırıcı, toksin atıcı.")},
        {"م", new BitkiDetay("Mersin", "Enfeksiyon önleyici, sindirim destekleyici, idrar söktürücü.")},
        {"ن", new BitkiDetay("Nane", "Mide bulantısını giderici, ferahlatıcı, nefes açıcı.")},
        {"ه", new BitkiDetay("Havuç", "Göz sağlığını destekleyici, bağışıklık artırıcı, beta-karoten kaynağı.")},
        {"و", new BitkiDetay("Üzüm", "Antioksidan deposu, damar sağlığını destekleyici, enerji verici.")},
        {"ي", new BitkiDetay("Yasemin", "Sinir sistemini yatıştırıcı, rahatlatıcı, uykusuzluğu giderici.")},
        
        // Ekstra genişletilmiş bitkiler
        {"چ", new BitkiDetay("Çörek Otu", "Bağışıklık güçlendirici, iltihap önleyici, sindirim destekleyici.")},
        {"پ", new BitkiDetay("Papatya", "Rahatlatıcı, mideyi yatıştırıcı, uyku düzenleyici.")},
        {"ژ", new BitkiDetay("Jojoba", "Cilt yenileyici, nemlendirici, iltihap önleyici.")},
        {"گ", new BitkiDetay("Ginseng", "Enerji artırıcı, bağışıklık destekleyici, beyin fonksiyonlarını geliştirici.")},
        {"ں", new BitkiDetay("Nar", "Antioksidan deposu, kalp dostu, sindirimi destekleyici.")},
        {"ۏ", new BitkiDetay("Vanilya", "Sinir yatıştırıcı, mutluluk verici, stres azaltıcı.")}
    };

        public static List<string> GetBitkiler(string harfler)
        {
            return harfler
                .Where(harf => ebcedBitkileri.ContainsKey(harf.ToString()))
                .Select(harf => ebcedBitkileri[harf.ToString()].Bitki)
                .Distinct()
                .ToList();
        }

        public static string GetDetay(string bitki)
        {
            var entry = ebcedBitkileri.Values.FirstOrDefault(e => e.Bitki == bitki);
            return entry != null ? entry.Detay : "Bu bitkiye ait detay bilgisi bulunamadı.";
        }
    }



}
