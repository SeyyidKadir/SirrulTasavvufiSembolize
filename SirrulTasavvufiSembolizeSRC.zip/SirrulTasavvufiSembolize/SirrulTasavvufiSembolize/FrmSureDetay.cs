﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmSureDetay : Form
    {
        public object sure85;
        
        public FrmSureDetay()
        {
            InitializeComponent();
        }

        private void FrmSureDetay_Load(object sender, EventArgs e)
        {
            txtAd.Text = ((Sure)sure85).AyetAd;
            txtOrAd.Text = ((Sure)sure85).OrjinalAyetAd;
            foreach (string ab in ((Sure)sure85).Gercek)
            {
                txtSureOrj.Text += ab + "\r\n";
            }
            foreach (string bb in ((Sure)sure85).Meal)
            {
                txtMeal.Text += bb + "\r\n";
            }
            
        }

        private void ebcedHesaplaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSureOrj.SelectedText))
            {
               long sonuc = EbcedHelper.ComputeEbcedValue(txtSureOrj.SelectedText);
               FrmEbcedSonuc snc1 = new FrmEbcedSonuc();
               snc1.sonuc1 = sonuc.ToString();
               snc1.Show();
            }
        }
    }
}
