﻿namespace SirrulTasavvufiSembolize
{
    partial class FrmSifaliBitkiArama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSifaliBitkiArama));
            this.LbSonuc = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtArapcaHarf = new System.Windows.Forms.TextBox();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.BtnSifaliBitkiAra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LbSonuc
            // 
            this.LbSonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.LbSonuc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.LbSonuc.FormattingEnabled = true;
            this.LbSonuc.ItemHeight = 25;
            this.LbSonuc.Location = new System.Drawing.Point(12, 163);
            this.LbSonuc.Name = "LbSonuc";
            this.LbSonuc.ScrollAlwaysVisible = true;
            this.LbSonuc.Size = new System.Drawing.Size(663, 179);
            this.LbSonuc.TabIndex = 12;
            this.LbSonuc.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LbSonuc_MouseDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(12, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "Sonuç :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Arapça Harf veya Harfler Girin:";
            // 
            // txtArapcaHarf
            // 
            this.txtArapcaHarf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtArapcaHarf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.txtArapcaHarf.Location = new System.Drawing.Point(291, 29);
            this.txtArapcaHarf.Name = "txtArapcaHarf";
            this.txtArapcaHarf.Size = new System.Drawing.Size(384, 30);
            this.txtArapcaHarf.TabIndex = 13;
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "button1.png");
            // 
            // BtnSifaliBitkiAra
            // 
            this.BtnSifaliBitkiAra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnSifaliBitkiAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnSifaliBitkiAra.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnSifaliBitkiAra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSifaliBitkiAra.ImageIndex = 0;
            this.BtnSifaliBitkiAra.ImageList = this.ımageList1;
            this.BtnSifaliBitkiAra.Location = new System.Drawing.Point(548, 65);
            this.BtnSifaliBitkiAra.Name = "BtnSifaliBitkiAra";
            this.BtnSifaliBitkiAra.Size = new System.Drawing.Size(127, 70);
            this.BtnSifaliBitkiAra.TabIndex = 15;
            this.BtnSifaliBitkiAra.Text = "Ara";
            this.BtnSifaliBitkiAra.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnSifaliBitkiAra.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnSifaliBitkiAra.UseVisualStyleBackColor = false;
            this.BtnSifaliBitkiAra.Click += new System.EventHandler(this.BtnSifaliBitkiAra_Click);
            // 
            // FrmSifaliBitkiArama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(687, 354);
            this.Controls.Add(this.BtnSifaliBitkiAra);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtArapcaHarf);
            this.Controls.Add(this.LbSonuc);
            this.Controls.Add(this.label4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmSifaliBitkiArama";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Şifalı Bitki Arama";
            this.Load += new System.EventHandler(this.FrmSifaliBitkiArama_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LbSonuc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtArapcaHarf;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button BtnSifaliBitkiAra;
    }
}