﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmEbcedSonuc : Form
    {
        public FrmEbcedSonuc()
        {
            InitializeComponent();
        }
        public string sonuc1;
        private void FrmEbcedSonuc_Load(object sender, EventArgs e)
        {
            txtSonuc.Text = sonuc1;
        }
    }
}
