﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmsayidanHarfedonustur : Form
    {
        public FrmsayidanHarfedonustur()
        {
            InitializeComponent();
        }

        private void BtnDonustur_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSayi.Text))
            {
                try
                {
                    Int64 sayi = Int64.Parse(txtSayi.Text);
                    string sonuc = EbcedHelper.ConvertNumberToArabic(sayi);
                    txtSonuc.Text = sonuc;
                }
                catch
                { 
                
                }
            }
        }
    }
}
