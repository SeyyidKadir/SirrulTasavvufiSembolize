﻿namespace SirrulTasavvufiSembolize
{
    partial class FrmArapcaDanTurkceLatinCevir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmArapcaDanTurkceLatinCevir));
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.txtDeger = new System.Windows.Forms.TextBox();
            this.BtnCevir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSonuc = new System.Windows.Forms.TextBox();
            this.CBTurkceKullan = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "button1.png");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Bir değer girin:";
            // 
            // txtDeger
            // 
            this.txtDeger.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtDeger.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.txtDeger.Location = new System.Drawing.Point(143, 22);
            this.txtDeger.Name = "txtDeger";
            this.txtDeger.Size = new System.Drawing.Size(255, 30);
            this.txtDeger.TabIndex = 2;
            // 
            // BtnCevir
            // 
            this.BtnCevir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnCevir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnCevir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnCevir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCevir.ImageIndex = 0;
            this.BtnCevir.ImageList = this.ımageList1;
            this.BtnCevir.Location = new System.Drawing.Point(223, 58);
            this.BtnCevir.Name = "BtnCevir";
            this.BtnCevir.Size = new System.Drawing.Size(175, 77);
            this.BtnCevir.TabIndex = 4;
            this.BtnCevir.Text = "Çevir";
            this.BtnCevir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnCevir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnCevir.UseVisualStyleBackColor = false;
            this.BtnCevir.Click += new System.EventHandler(this.BtnDonustur_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 196);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Sonuç:";
            // 
            // txtSonuc
            // 
            this.txtSonuc.BackColor = System.Drawing.Color.White;
            this.txtSonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSonuc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.txtSonuc.Location = new System.Drawing.Point(85, 211);
            this.txtSonuc.Multiline = true;
            this.txtSonuc.Name = "txtSonuc";
            this.txtSonuc.ReadOnly = true;
            this.txtSonuc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSonuc.Size = new System.Drawing.Size(313, 154);
            this.txtSonuc.TabIndex = 6;
            // 
            // CBTurkceKullan
            // 
            this.CBTurkceKullan.AutoSize = true;
            this.CBTurkceKullan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.CBTurkceKullan.ForeColor = System.Drawing.Color.White;
            this.CBTurkceKullan.Location = new System.Drawing.Point(16, 151);
            this.CBTurkceKullan.Name = "CBTurkceKullan";
            this.CBTurkceKullan.Size = new System.Drawing.Size(247, 24);
            this.CBTurkceKullan.TabIndex = 8;
            this.CBTurkceKullan.Text = "Türkçe Karakterleri Kullan";
            this.CBTurkceKullan.UseVisualStyleBackColor = true;
            // 
            // FrmArapcaDanTurkceLatinCevir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(410, 379);
            this.Controls.Add(this.CBTurkceKullan);
            this.Controls.Add(this.txtSonuc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnCevir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDeger);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(416, 409);
            this.MinimumSize = new System.Drawing.Size(416, 409);
            this.Name = "FrmArapcaDanTurkceLatinCevir";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Arapçadan Latin Veya Türkçeye Çevir";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDeger;
        private System.Windows.Forms.Button BtnCevir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSonuc;
        private System.Windows.Forms.CheckBox CBTurkceKullan;
    }
}