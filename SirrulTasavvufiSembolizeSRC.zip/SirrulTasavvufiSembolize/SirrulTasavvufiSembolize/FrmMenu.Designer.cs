﻿namespace SirrulTasavvufiSembolize
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            this.BtnArapcaDanLatine = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.BtnRemilDonusum = new System.Windows.Forms.Button();
            this.BtnLatinArapcaDonustur = new System.Windows.Forms.Button();
            this.BtnSayidanHarf = new System.Windows.Forms.Button();
            this.BtnEbcedHesapla = new System.Windows.Forms.Button();
            this.BtnKuranArama = new System.Windows.Forms.Button();
            this.BtnSifaliBitkiler = new System.Windows.Forms.Button();
            this.BtnHakkinda = new System.Windows.Forms.Button();
            this.BtnElementler = new System.Windows.Forms.Button();
            this.BtnArapcaTemizle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnArapcaDanLatine
            // 
            this.BtnArapcaDanLatine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnArapcaDanLatine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnArapcaDanLatine.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnArapcaDanLatine.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnArapcaDanLatine.ImageIndex = 0;
            this.BtnArapcaDanLatine.ImageList = this.ımageList1;
            this.BtnArapcaDanLatine.Location = new System.Drawing.Point(209, 174);
            this.BtnArapcaDanLatine.Name = "BtnArapcaDanLatine";
            this.BtnArapcaDanLatine.Size = new System.Drawing.Size(344, 67);
            this.BtnArapcaDanLatine.TabIndex = 7;
            this.BtnArapcaDanLatine.Text = "Arapçadan Latinceye Veya Türkçeye Dönüştür";
            this.BtnArapcaDanLatine.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnArapcaDanLatine.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnArapcaDanLatine.UseVisualStyleBackColor = false;
            this.BtnArapcaDanLatine.Click += new System.EventHandler(this.BtnArapcaDanLatine_Click);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "button1.png");
            // 
            // BtnRemilDonusum
            // 
            this.BtnRemilDonusum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnRemilDonusum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnRemilDonusum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnRemilDonusum.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnRemilDonusum.ImageIndex = 0;
            this.BtnRemilDonusum.ImageList = this.ımageList1;
            this.BtnRemilDonusum.Location = new System.Drawing.Point(12, 174);
            this.BtnRemilDonusum.Name = "BtnRemilDonusum";
            this.BtnRemilDonusum.Size = new System.Drawing.Size(181, 80);
            this.BtnRemilDonusum.TabIndex = 5;
            this.BtnRemilDonusum.Text = "Remil İşlemleri";
            this.BtnRemilDonusum.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnRemilDonusum.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnRemilDonusum.UseVisualStyleBackColor = false;
            this.BtnRemilDonusum.Click += new System.EventHandler(this.BtnRemilDonusum_Click);
            // 
            // BtnLatinArapcaDonustur
            // 
            this.BtnLatinArapcaDonustur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnLatinArapcaDonustur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnLatinArapcaDonustur.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnLatinArapcaDonustur.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnLatinArapcaDonustur.ImageIndex = 0;
            this.BtnLatinArapcaDonustur.ImageList = this.ımageList1;
            this.BtnLatinArapcaDonustur.Location = new System.Drawing.Point(280, 88);
            this.BtnLatinArapcaDonustur.Name = "BtnLatinArapcaDonustur";
            this.BtnLatinArapcaDonustur.Size = new System.Drawing.Size(273, 70);
            this.BtnLatinArapcaDonustur.TabIndex = 6;
            this.BtnLatinArapcaDonustur.Text = "Latin den Arapçaya Dönüştür";
            this.BtnLatinArapcaDonustur.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnLatinArapcaDonustur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnLatinArapcaDonustur.UseVisualStyleBackColor = false;
            this.BtnLatinArapcaDonustur.Click += new System.EventHandler(this.BtnLatinArapcaDonustur_Click);
            // 
            // BtnSayidanHarf
            // 
            this.BtnSayidanHarf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnSayidanHarf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnSayidanHarf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnSayidanHarf.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSayidanHarf.ImageIndex = 0;
            this.BtnSayidanHarf.ImageList = this.ımageList1;
            this.BtnSayidanHarf.Location = new System.Drawing.Point(12, 260);
            this.BtnSayidanHarf.Name = "BtnSayidanHarf";
            this.BtnSayidanHarf.Size = new System.Drawing.Size(319, 70);
            this.BtnSayidanHarf.TabIndex = 4;
            this.BtnSayidanHarf.Text = "Sayıdan Harfe Dönüştür";
            this.BtnSayidanHarf.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnSayidanHarf.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnSayidanHarf.UseVisualStyleBackColor = false;
            this.BtnSayidanHarf.Click += new System.EventHandler(this.BtnSayidanHarf_Click);
            // 
            // BtnEbcedHesapla
            // 
            this.BtnEbcedHesapla.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnEbcedHesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnEbcedHesapla.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnEbcedHesapla.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEbcedHesapla.ImageIndex = 0;
            this.BtnEbcedHesapla.ImageList = this.ımageList1;
            this.BtnEbcedHesapla.Location = new System.Drawing.Point(12, 88);
            this.BtnEbcedHesapla.Name = "BtnEbcedHesapla";
            this.BtnEbcedHesapla.Size = new System.Drawing.Size(172, 80);
            this.BtnEbcedHesapla.TabIndex = 3;
            this.BtnEbcedHesapla.Text = "Ebced Hesapla";
            this.BtnEbcedHesapla.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnEbcedHesapla.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnEbcedHesapla.UseVisualStyleBackColor = false;
            this.BtnEbcedHesapla.Click += new System.EventHandler(this.BtnEbcedHesapla_Click);
            // 
            // BtnKuranArama
            // 
            this.BtnKuranArama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnKuranArama.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnKuranArama.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnKuranArama.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnKuranArama.ImageIndex = 0;
            this.BtnKuranArama.ImageList = this.ımageList1;
            this.BtnKuranArama.Location = new System.Drawing.Point(12, 12);
            this.BtnKuranArama.Name = "BtnKuranArama";
            this.BtnKuranArama.Size = new System.Drawing.Size(236, 70);
            this.BtnKuranArama.TabIndex = 2;
            this.BtnKuranArama.Text = "Kuranda Arama";
            this.BtnKuranArama.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnKuranArama.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnKuranArama.UseVisualStyleBackColor = false;
            this.BtnKuranArama.Click += new System.EventHandler(this.BtnKuranArama_Click);
            // 
            // BtnSifaliBitkiler
            // 
            this.BtnSifaliBitkiler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnSifaliBitkiler.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnSifaliBitkiler.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnSifaliBitkiler.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSifaliBitkiler.ImageIndex = 0;
            this.BtnSifaliBitkiler.ImageList = this.ımageList1;
            this.BtnSifaliBitkiler.Location = new System.Drawing.Point(265, 12);
            this.BtnSifaliBitkiler.Name = "BtnSifaliBitkiler";
            this.BtnSifaliBitkiler.Size = new System.Drawing.Size(288, 66);
            this.BtnSifaliBitkiler.TabIndex = 8;
            this.BtnSifaliBitkiler.Text = "Bilinen Şifalı Bitkiler Arama";
            this.BtnSifaliBitkiler.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnSifaliBitkiler.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnSifaliBitkiler.UseVisualStyleBackColor = false;
            this.BtnSifaliBitkiler.Click += new System.EventHandler(this.BtnSifaliBitkiler_Click);
            // 
            // BtnHakkinda
            // 
            this.BtnHakkinda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnHakkinda.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnHakkinda.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnHakkinda.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnHakkinda.ImageIndex = 0;
            this.BtnHakkinda.ImageList = this.ımageList1;
            this.BtnHakkinda.Location = new System.Drawing.Point(337, 331);
            this.BtnHakkinda.Name = "BtnHakkinda";
            this.BtnHakkinda.Size = new System.Drawing.Size(216, 80);
            this.BtnHakkinda.TabIndex = 9;
            this.BtnHakkinda.Text = "Hakkında";
            this.BtnHakkinda.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnHakkinda.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnHakkinda.UseVisualStyleBackColor = false;
            this.BtnHakkinda.Click += new System.EventHandler(this.BtnHakkinda_Click);
            // 
            // BtnElementler
            // 
            this.BtnElementler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnElementler.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnElementler.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnElementler.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnElementler.ImageIndex = 0;
            this.BtnElementler.ImageList = this.ımageList1;
            this.BtnElementler.Location = new System.Drawing.Point(12, 336);
            this.BtnElementler.Name = "BtnElementler";
            this.BtnElementler.Size = new System.Drawing.Size(319, 70);
            this.BtnElementler.TabIndex = 10;
            this.BtnElementler.Text = "Sayıdan Element Ara";
            this.BtnElementler.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnElementler.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnElementler.UseVisualStyleBackColor = false;
            this.BtnElementler.Click += new System.EventHandler(this.BtnElementler_Click);
            // 
            // BtnArapcaTemizle
            // 
            this.BtnArapcaTemizle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnArapcaTemizle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnArapcaTemizle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnArapcaTemizle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnArapcaTemizle.ImageIndex = 0;
            this.BtnArapcaTemizle.ImageList = this.ımageList1;
            this.BtnArapcaTemizle.Location = new System.Drawing.Point(337, 245);
            this.BtnArapcaTemizle.Name = "BtnArapcaTemizle";
            this.BtnArapcaTemizle.Size = new System.Drawing.Size(216, 80);
            this.BtnArapcaTemizle.TabIndex = 11;
            this.BtnArapcaTemizle.Text = "Şedde Vb Temizle";
            this.BtnArapcaTemizle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnArapcaTemizle.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnArapcaTemizle.UseVisualStyleBackColor = false;
            this.BtnArapcaTemizle.Click += new System.EventHandler(this.BtnArapcaTemizle_Click);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(574, 412);
            this.Controls.Add(this.BtnArapcaTemizle);
            this.Controls.Add(this.BtnElementler);
            this.Controls.Add(this.BtnEbcedHesapla);
            this.Controls.Add(this.BtnHakkinda);
            this.Controls.Add(this.BtnRemilDonusum);
            this.Controls.Add(this.BtnArapcaDanLatine);
            this.Controls.Add(this.BtnSifaliBitkiler);
            this.Controls.Add(this.BtnKuranArama);
            this.Controls.Add(this.BtnSayidanHarf);
            this.Controls.Add(this.BtnLatinArapcaDonustur);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(580, 442);
            this.MinimumSize = new System.Drawing.Size(580, 442);
            this.Name = "FrmMenu";
            this.Opacity = 0.9;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "İşlemler Menüsü";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmMenu_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnKuranArama;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button BtnEbcedHesapla;
        private System.Windows.Forms.Button BtnSayidanHarf;
        private System.Windows.Forms.Button BtnRemilDonusum;
        private System.Windows.Forms.Button BtnLatinArapcaDonustur;
        private System.Windows.Forms.Button BtnArapcaDanLatine;
        private System.Windows.Forms.Button BtnSifaliBitkiler;
        private System.Windows.Forms.Button BtnHakkinda;
        private System.Windows.Forms.Button BtnElementler;
        private System.Windows.Forms.Button BtnArapcaTemizle;
    }
}