﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmBitkiDetay : Form
    {
        public string detay_bitki;
        public string ad_bitki;
        public FrmBitkiDetay()
        {
            InitializeComponent();
        }

        private void FrmBitkiDetay_Load(object sender, EventArgs e)
        {
            txtBitkiAd.Text = ad_bitki;
            txtDetay.Text = detay_bitki;
        }
    }
}
