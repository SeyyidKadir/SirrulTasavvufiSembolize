﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmSifaliBitkiArama : Form
    {
        List<string> sonuc;
        string baslik1 = "";
        public FrmSifaliBitkiArama()
        {
            InitializeComponent();
        }

       

        private void FrmSifaliBitkiArama_Load(object sender, EventArgs e)
        {
            baslik1 = this.Text;
        }

        private void LbSonuc_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (LbSonuc.SelectedIndex != -1)
            {
                FrmBitkiDetay detay1 = new FrmBitkiDetay();
                detay1.ad_bitki = sonuc[LbSonuc.SelectedIndex];
                detay1.detay_bitki = STS_Sifa.GetDetay(sonuc[LbSonuc.SelectedIndex]);
                detay1.Show();
            }
        }

        private void BtnSifaliBitkiAra_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtArapcaHarf.Text))
            {
                sonuc = new List<string>();
                LbSonuc.Items.Clear();
                sonuc = STS_Sifa.GetBitkiler(txtArapcaHarf.Text);
                foreach (string s in sonuc)
                {
                    LbSonuc.Items.Add(s);
                }
                this.Text = baslik1 + " (Toplam :" + LbSonuc.Items.Count.ToString() + ") Sonuç Bulundu.";
            }
        }
    }
}
