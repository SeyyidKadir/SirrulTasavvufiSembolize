﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmAtomNumarasindanAtomBul : Form
    {
        public FrmAtomNumarasindanAtomBul()
        {
            InitializeComponent();
        }

        private void BtnElementBul_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtSayi.Text))
            {
                try
                {
                    Element elem = new PeriyodikTablo().GetElementByNumber(int.Parse(txtSayi.Text));
                    txtSonuc.Text = "Adı : " + elem.Isim.ToString() + " Simgesi : " + elem.Sembol.ToString();
                }
                catch
                { 
                
                }
            }
        }
    }
}
