﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmKuranArama : Form
    {
        public FrmKuranArama()
        {
            InitializeComponent();
        }
        kuran kuran1 = new kuran();
        Sure sure_secilen;
        List<Sure> sureler = new List<Sure>();
        string baslik1;
        private void FrmKuranArama_Load(object sender, EventArgs e)
        {
            CmbSureNo.Items.Clear();
            for (int i = 0; i < kuran1.Sureuzunluklar(); i++)
            {
                CmbSureNo.Items.Add(i.ToString());
            }
            baslik1 = this.Text;
        }

        private void BtnSureGetir_Click(object sender, EventArgs e)
        {
            if (CmbSureNo.SelectedIndex != -1)
            {
               LbSonuc.Items.Clear();
               Sure sure1 = kuran1.SureAl(int.Parse(CmbSureNo.SelectedItem.ToString()));
               LbSonuc.Items.Add(sure1.AyetAd + "<->" + sure1.OrjinalAyetAd);
               sure_secilen = sure1;
            }
        }

        private void LbSonuc_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (LbSonuc.SelectedIndex != -1)
            {
                if (LbSonuc.Items.Count == 1)
                {
                    FrmSureDetay detay1 = new FrmSureDetay();
                    detay1.sure85 = this.sure_secilen;
                    detay1.Show();
                }
                else
                {
                    FrmSureDetay detay1 = new FrmSureDetay();
                    detay1.sure85 = this.sureler[LbSonuc.SelectedIndex];
                    detay1.Show();
                }
            
            }
        }

        private void BtnKuranArama_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCumle.Text))
            {
                if (CmbAyar.SelectedIndex == 0)
                {
                    LbSonuc.Items.Clear();
                    this.sureler = new List<Sure>();
                    Sure[] sureler1 = kuran1.Arama(txtCumle.Text, kuran.AramaAyarlari.Turkce);
                    foreach (Sure s1 in sureler1)
                    {
                        this.sureler.Add(s1);
                    }
                    foreach (Sure h1 in this.sureler)
                    {
                        LbSonuc.Items.Add(h1.AyetAd + "<->" + h1.OrjinalAyetAd);
                    }
                    this.Text = baslik1 + " (Toplam :" + LbSonuc.Items.Count.ToString() + ") Kayıt Bulundu.";
                   

                }
                else
                {
                    LbSonuc.Items.Clear();
                    this.sureler = new List<Sure>();
                    Sure[] sureler1 = kuran1.Arama(txtCumle.Text, kuran.AramaAyarlari.Arapca);
                    foreach (Sure s1 in sureler1)
                    {
                        this.sureler.Add(s1);
                    }
                    foreach (Sure h1 in this.sureler)
                    {
                        LbSonuc.Items.Add(h1.AyetAd + "<->" + h1.OrjinalAyetAd);
                    }
                    this.Text = baslik1 + " (Toplam :" + LbSonuc.Items.Count.ToString() + ") Kayıt Bulundu.";
                }
            }
        }

        
    }
}
