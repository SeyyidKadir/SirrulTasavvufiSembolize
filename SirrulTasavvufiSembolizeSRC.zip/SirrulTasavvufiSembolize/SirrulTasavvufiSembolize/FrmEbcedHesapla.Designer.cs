﻿namespace SirrulTasavvufiSembolize
{
    partial class FrmEbcedHesapla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEbcedHesapla));
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.BtnEbcedHesapla = new System.Windows.Forms.Button();
            this.txtYaziArap = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "button1.png");
            // 
            // BtnEbcedHesapla
            // 
            this.BtnEbcedHesapla.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnEbcedHesapla.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnEbcedHesapla.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnEbcedHesapla.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEbcedHesapla.ImageIndex = 0;
            this.BtnEbcedHesapla.ImageList = this.ımageList1;
            this.BtnEbcedHesapla.Location = new System.Drawing.Point(109, 103);
            this.BtnEbcedHesapla.Name = "BtnEbcedHesapla";
            this.BtnEbcedHesapla.Size = new System.Drawing.Size(231, 70);
            this.BtnEbcedHesapla.TabIndex = 3;
            this.BtnEbcedHesapla.Text = "Ebced Hesapla";
            this.BtnEbcedHesapla.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnEbcedHesapla.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnEbcedHesapla.UseVisualStyleBackColor = false;
            this.BtnEbcedHesapla.Click += new System.EventHandler(this.BtnEbcedHesapla_Click);
            // 
            // txtYaziArap
            // 
            this.txtYaziArap.BackColor = System.Drawing.Color.White;
            this.txtYaziArap.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtYaziArap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.txtYaziArap.Location = new System.Drawing.Point(73, 46);
            this.txtYaziArap.Name = "txtYaziArap";
            this.txtYaziArap.Size = new System.Drawing.Size(268, 38);
            this.txtYaziArap.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Girdi :";
            // 
            // FrmEbcedHesapla
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(353, 189);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtYaziArap);
            this.Controls.Add(this.BtnEbcedHesapla);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(359, 215);
            this.MinimumSize = new System.Drawing.Size(359, 215);
            this.Name = "FrmEbcedHesapla";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ebced Hesapla(Arapça)";
            this.Load += new System.EventHandler(this.FrmEbcedHesapla_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button BtnEbcedHesapla;
        private System.Windows.Forms.TextBox txtYaziArap;
        private System.Windows.Forms.Label label1;
    }
}