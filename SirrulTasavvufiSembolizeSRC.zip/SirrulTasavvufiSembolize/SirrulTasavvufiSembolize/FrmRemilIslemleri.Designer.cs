﻿namespace SirrulTasavvufiSembolize
{
    partial class FrmRemilIslemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRemilIslemleri));
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.txtSayi = new System.Windows.Forms.TextBox();
            this.BtnDonustur = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSonuc = new System.Windows.Forms.TextBox();
            this.CBGenisletilmis = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "button1.png");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Bir sayı girin:";
            // 
            // txtSayi
            // 
            this.txtSayi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSayi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.txtSayi.Location = new System.Drawing.Point(135, 23);
            this.txtSayi.Name = "txtSayi";
            this.txtSayi.Size = new System.Drawing.Size(267, 30);
            this.txtSayi.TabIndex = 2;
            // 
            // BtnDonustur
            // 
            this.BtnDonustur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnDonustur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnDonustur.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnDonustur.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnDonustur.ImageIndex = 0;
            this.BtnDonustur.ImageList = this.ımageList1;
            this.BtnDonustur.Location = new System.Drawing.Point(227, 59);
            this.BtnDonustur.Name = "BtnDonustur";
            this.BtnDonustur.Size = new System.Drawing.Size(175, 77);
            this.BtnDonustur.TabIndex = 4;
            this.BtnDonustur.Text = "Dönüştür";
            this.BtnDonustur.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnDonustur.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnDonustur.UseVisualStyleBackColor = false;
            this.BtnDonustur.Click += new System.EventHandler(this.BtnDonustur_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 211);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Sonuç:";
            // 
            // txtSonuc
            // 
            this.txtSonuc.BackColor = System.Drawing.Color.White;
            this.txtSonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSonuc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.txtSonuc.Location = new System.Drawing.Point(85, 211);
            this.txtSonuc.Multiline = true;
            this.txtSonuc.Name = "txtSonuc";
            this.txtSonuc.ReadOnly = true;
            this.txtSonuc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSonuc.Size = new System.Drawing.Size(313, 154);
            this.txtSonuc.TabIndex = 6;
            // 
            // CBGenisletilmis
            // 
            this.CBGenisletilmis.AutoSize = true;
            this.CBGenisletilmis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.CBGenisletilmis.ForeColor = System.Drawing.Color.White;
            this.CBGenisletilmis.Location = new System.Drawing.Point(10, 152);
            this.CBGenisletilmis.Name = "CBGenisletilmis";
            this.CBGenisletilmis.Size = new System.Drawing.Size(258, 24);
            this.CBGenisletilmis.TabIndex = 7;
            this.CBGenisletilmis.Text = "Genişletilmiş Listeyi Kullan";
            this.CBGenisletilmis.UseVisualStyleBackColor = true;
            // 
            // FrmRemilIslemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(410, 379);
            this.Controls.Add(this.CBGenisletilmis);
            this.Controls.Add(this.txtSonuc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnDonustur);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSayi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(416, 409);
            this.MinimumSize = new System.Drawing.Size(416, 409);
            this.Name = "FrmRemilIslemleri";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Remil İşlemleri";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSayi;
        private System.Windows.Forms.Button BtnDonustur;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSonuc;
        private System.Windows.Forms.CheckBox CBGenisletilmis;
    }
}