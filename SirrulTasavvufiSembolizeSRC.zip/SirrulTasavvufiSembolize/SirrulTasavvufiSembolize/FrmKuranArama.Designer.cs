﻿namespace SirrulTasavvufiSembolize
{
    partial class FrmKuranArama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmKuranArama));
            this.txtCumle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.BtnKuranArama = new System.Windows.Forms.Button();
            this.CmbAyar = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CmbSureNo = new System.Windows.Forms.ComboBox();
            this.BtnSureGetir = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.LbSonuc = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtCumle
            // 
            this.txtCumle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtCumle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.txtCumle.Location = new System.Drawing.Point(112, 12);
            this.txtCumle.Name = "txtCumle";
            this.txtCumle.Size = new System.Drawing.Size(267, 30);
            this.txtCumle.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bir kelime :";
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "button1.png");
            // 
            // BtnKuranArama
            // 
            this.BtnKuranArama.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnKuranArama.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnKuranArama.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnKuranArama.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnKuranArama.ImageIndex = 0;
            this.BtnKuranArama.ImageList = this.ımageList1;
            this.BtnKuranArama.Location = new System.Drawing.Point(255, 47);
            this.BtnKuranArama.Name = "BtnKuranArama";
            this.BtnKuranArama.Size = new System.Drawing.Size(127, 70);
            this.BtnKuranArama.TabIndex = 3;
            this.BtnKuranArama.Text = "Ara";
            this.BtnKuranArama.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnKuranArama.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnKuranArama.UseVisualStyleBackColor = false;
            this.BtnKuranArama.Click += new System.EventHandler(this.BtnKuranArama_Click);
            // 
            // CmbAyar
            // 
            this.CmbAyar.BackColor = System.Drawing.Color.White;
            this.CmbAyar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbAyar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.CmbAyar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.CmbAyar.FormattingEnabled = true;
            this.CmbAyar.Items.AddRange(new object[] {
            "Türkçe",
            "Arapça"});
            this.CmbAyar.Location = new System.Drawing.Point(128, 58);
            this.CmbAyar.Name = "CmbAyar";
            this.CmbAyar.Size = new System.Drawing.Size(121, 33);
            this.CmbAyar.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(0, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Arama Şekli :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(476, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Sure No :";
            // 
            // CmbSureNo
            // 
            this.CmbSureNo.BackColor = System.Drawing.Color.White;
            this.CmbSureNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbSureNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.CmbSureNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.CmbSureNo.FormattingEnabled = true;
            this.CmbSureNo.Location = new System.Drawing.Point(571, 14);
            this.CmbSureNo.Name = "CmbSureNo";
            this.CmbSureNo.Size = new System.Drawing.Size(121, 33);
            this.CmbSureNo.TabIndex = 6;
            // 
            // BtnSureGetir
            // 
            this.BtnSureGetir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(221)))), ((int)(((byte)(182)))));
            this.BtnSureGetir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnSureGetir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.BtnSureGetir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSureGetir.ImageIndex = 0;
            this.BtnSureGetir.ImageList = this.ımageList1;
            this.BtnSureGetir.Location = new System.Drawing.Point(557, 58);
            this.BtnSureGetir.Name = "BtnSureGetir";
            this.BtnSureGetir.Size = new System.Drawing.Size(135, 71);
            this.BtnSureGetir.TabIndex = 8;
            this.BtnSureGetir.Text = "Getir";
            this.BtnSureGetir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnSureGetir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnSureGetir.UseVisualStyleBackColor = false;
            this.BtnSureGetir.Click += new System.EventHandler(this.BtnSureGetir_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(1, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Sonuç :";
            // 
            // LbSonuc
            // 
            this.LbSonuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.LbSonuc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(234)))), ((int)(((byte)(199)))));
            this.LbSonuc.FormattingEnabled = true;
            this.LbSonuc.ItemHeight = 25;
            this.LbSonuc.Location = new System.Drawing.Point(4, 168);
            this.LbSonuc.Name = "LbSonuc";
            this.LbSonuc.ScrollAlwaysVisible = true;
            this.LbSonuc.Size = new System.Drawing.Size(687, 179);
            this.LbSonuc.TabIndex = 10;
            this.LbSonuc.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LbSonuc_MouseDoubleClick);
            // 
            // FrmKuranArama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(92)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(705, 352);
            this.Controls.Add(this.LbSonuc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.BtnSureGetir);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CmbSureNo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CmbAyar);
            this.Controls.Add(this.BtnKuranArama);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCumle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(711, 382);
            this.MinimumSize = new System.Drawing.Size(711, 382);
            this.Name = "FrmKuranArama";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kuranda Arama";
            this.Load += new System.EventHandler(this.FrmKuranArama_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCumle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button BtnKuranArama;
        private System.Windows.Forms.ComboBox CmbAyar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox CmbSureNo;
        private System.Windows.Forms.Button BtnSureGetir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox LbSonuc;
    }
}