﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SirrulTasavvufiSembolize
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void FrmMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void BtnKuranArama_Click(object sender, EventArgs e)
        {
            new FrmKuranArama().Show();
        }

        private void BtnEbcedHesapla_Click(object sender, EventArgs e)
        {
            new FrmEbcedHesapla().Show();
        }

        private void BtnRemilDonusum_Click(object sender, EventArgs e)
        {
            new FrmRemilIslemleri().Show();
        }

        private void BtnSayidanHarf_Click(object sender, EventArgs e)
        {
            new FrmsayidanHarfedonustur().Show();
        }

        private void BtnLatinArapcaDonustur_Click(object sender, EventArgs e)
        {
            new FrmLatinToArabic().Show();
        }

        private void BtnArapcaDanLatine_Click(object sender, EventArgs e)
        {
            new FrmArapcaDanTurkceLatinCevir().Show();
        }

        private void BtnSifaliBitkiler_Click(object sender, EventArgs e)
        {
            new FrmSifaliBitkiArama().Show();
        }

        private void BtnElementler_Click(object sender, EventArgs e)
        {
            new FrmAtomNumarasindanAtomBul().Show();
        }

        private void BtnArapcaTemizle_Click(object sender, EventArgs e)
        {
            new FrmTemizleArapca().Show();
        }

        private void BtnHakkinda_Click(object sender, EventArgs e)
        {
            new FrmAbout().ShowDialog();
        }
    }
}
